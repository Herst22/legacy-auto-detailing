// app/layout.tsx

import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://legacyautodetailingar.com"),
  title: {
    default: "Legacy Auto Detailing LLC | Premium Mobile Auto Detailing",
    template: "%s | Legacy Auto Detailing LLC",
  },
  description:
    "Luxury mobile auto detailing in Arkansas specializing in ceramic coatings, paint correction, interior detailing, exterior detailing, and maintenance memberships.",
  keywords: [
    "Legacy Auto Detailing",
    "Auto Detailing Arkansas",
    "Mobile Detailing",
    "Ceramic Coating",
    "Paint Correction",
    "Interior Detailing",
    "Exterior Detailing",
    "Car Detailing",
    "Arkansas Detailer",
  ],
  authors: [{ name: "Legacy Auto Detailing LLC" }],
  creator: "Legacy Auto Detailing LLC",
  publisher: "Legacy Auto Detailing LLC",
  applicationName: "Legacy Auto Detailing LLC",
  category: "Automotive",
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    title: "Legacy Auto Detailing LLC",
    description:
      "Luxury mobile detailing with premium results, monthly memberships, and 20% discounts for Military & First Responders.",
    url: "https://legacyautodetailingar.com",
    siteName: "Legacy Auto Detailing LLC",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Legacy Auto Detailing LLC",
    description:
      "Premium mobile detailing built on Faith • Honor • Strength.",
  },
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.className} bg-black text-white antialiased selection:bg-yellow-500 selection:text-black`}
      >
        {children}
      </body>
    </html>
  );
}