"use client";

import { motion } from "framer-motion";
import {
  Car,
  Sparkles,
  Shield,
  Droplets,
  BrushCleaning,
  BadgeCheck,
} from "lucide-react";

const services = [
  {
    icon: Car,
    title: "Exterior Detail",
    description:
      "Safe hand wash, wheel cleaning, tire shine, bug removal, streak-free glass, and premium paint protection.",
  },
  {
    icon: BrushCleaning,
    title: "Interior Detail",
    description:
      "Complete vacuum, shampoo, leather conditioning, plastics cleaned, vents detailed, and odor removal.",
  },
  {
    icon: Sparkles,
    title: "Paint Correction",
    description:
      "Professional machine polishing that removes oxidation and swirl marks while restoring incredible gloss.",
  },
  {
    icon: Shield,
    title: "Ceramic Coating",
    description:
      "Long-lasting ceramic protection that delivers incredible shine and hydrophobic performance.",
  },
  {
    icon: Droplets,
    title: "Engine Bay Cleaning",
    description:
      "Carefully detailed engine compartments using safe techniques and premium products.",
  },
  {
    icon: BadgeCheck,
    title: "Membership Plans",
    description:
      "Monthly maintenance plans that keep your vehicle looking freshly detailed all year.",
  },
];

export default function Services() {
  return (
    <section
      id="services"
      className="bg-[#050505] py-24"
    >
      <div className="mx-auto max-w-7xl px-6">

        <motion.div
          initial={{ opacity: 0, y: 35 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: .6 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="font-semibold uppercase tracking-[0.35em] text-yellow-400">
            Our Services
          </p>

          <h2 className="section-title mt-4">
            Premium Auto Detailing
          </h2>

          <div className="gold-divider" />

          <p className="section-subtitle">
            Every service is performed using premium products with meticulous
            attention to every detail.
          </p>
        </motion.div>

        <div className="mt-16 grid gap-8 md:grid-cols-2 xl:grid-cols-3">
                {services.map((service, index) => {
            const Icon = service.icon;

            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.08,
                }}
                viewport={{ once: true }}
                className="glass group rounded-3xl border border-white/10 p-8 transition-all duration-300 hover:-translate-y-2 hover:border-yellow-500/40"
              >
                <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-yellow-500/10 text-yellow-400 transition-all group-hover:bg-yellow-500 group-hover:text-black">
                  <Icon className="h-8 w-8" />
                </div>

                <h3 className="text-2xl font-black text-white">
                  {service.title}
                </h3>

                <p className="mt-4 leading-7 text-gray-300">
                  {service.description}
                </p>

                <div className="mt-8">
                  <a
                    href="#contact"
                    className="font-semibold text-yellow-400 transition hover:text-yellow-300"
                  >
                    Schedule Service →
                  </a>
                </div>
              </motion.div>
            );
          })}
        </div>
                <motion.div
         initial={{ opacity: 0, y: 35 }}
         whileInView={{ opacity: 1, y: 0 }}
         transition={{ duration: 0.6 }}
         viewport={{ once: true }}
         className="mt-20 rounded-3xl border border-yellow-500/20 bg-gradient-to-r from-yellow-500/10 via-black to-yellow-500/10 p-10 text-center"
         >
         <h3 className="text-3xl font-black text-white">
           Why Choose Legacy Auto Detailing?
         </h3>

         <p className="mx-auto mt-6 max-w-3xl text-lg leading-8 text-gray-300">
           We don't just clean vehicles—we restore, protect, and preserve your
           investment. Every detail is completed with professional equipment,
           premium chemicals, and the same level of care we'd expect for our
           own vehicles.
         </p>

         <div className="mt-10 grid gap-6 md:grid-cols-4">
           <div>
             <h4 className="text-4xl font-black text-yellow-400">100%</h4>
             <p className="mt-2 text-gray-300">Satisfaction Guaranteed</p>
           </div>

           <div>
             <h4 className="text-4xl font-black text-yellow-400">Premium</h4>
             <p className="mt-2 text-gray-300">Professional Products</p>
           </div>

           <div>
             <h4 className="text-4xl font-black text-yellow-400">Mobile</h4>
             <p className="mt-2 text-gray-300">We Come To You</p>
           </div>

           <div>
             <h4 className="text-4xl font-black text-yellow-400">20% OFF</h4>
             <p className="mt-2 text-gray-300">
               Military & First Responders
             </p>
           </div>
         </div>

         <a
           href="#contact"
           className="gold-button mt-10 inline-flex rounded-full px-10 py-4 text-lg"
           >
           Book Your Appointment
         </a>
       </motion.div>
     </div>
   </section>
 );
}