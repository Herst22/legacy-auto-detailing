"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X, Phone, Calendar } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const links = [
  { name: "Home", href: "#home" },
  { name: "Services", href: "#services" },
  { name: "Pricing", href: "#pricing" },
  { name: "Memberships", href: "#memberships" },
  { name: "Gallery", href: "#gallery" },
  { name: "Why Legacy", href: "#why-legacy" },
  { name: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-black/95 backdrop-blur-lg border-b border-yellow-500/20 shadow-xl"
          : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6">
        <Link
          href="#home"
          className="text-2xl font-black tracking-wide text-white"
        >
          <span className="text-yellow-400">LEGACY</span>{" "}
          <span className="text-white">AUTO DETAILING</span>
        </Link>

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-sm font-semibold uppercase tracking-wider text-white transition hover:text-yellow-400"
            >
              {link.name}
            </a>
          ))}
        </nav>
<div className="hidden items-center gap-4 lg:flex">
          <a
            href="tel:+15010000000"
            className="flex items-center gap-2 text-sm font-semibold text-white transition hover:text-yellow-400"
          >
            <Phone className="h-4 w-4 text-yellow-400" />
            Call Now
          </a>

          <a
            href="#contact"
            className="gold-button flex items-center gap-2 rounded-full px-6 py-3"
          >
            <Calendar className="h-4 w-4" />
            Book Now
          </a>
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="text-white lg:hidden"
        >
          {mobileOpen ? (
            <X className="h-8 w-8" />
          ) : (
            <Menu className="h-8 w-8" />
          )}
        </button>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            className="border-t border-yellow-500/20 bg-black lg:hidden"
          >
            <nav className="flex flex-col px-6 py-6">
              {links.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="border-b border-white/10 py-4 text-white transition hover:text-yellow-400"
                >
                  {link.name}
                </a>
              ))}

              <a
                href="#contact"
                onClick={() => setMobileOpen(false)}
                className="gold-button mt-6 flex items-center justify-center rounded-full px-6 py-3"
              >
                Book Your Detail
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
