"use client";

import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, Star, Sparkles } from "lucide-react";

export default function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden bg-black"
    >
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[url('/images/hero.jpg')] bg-cover bg-center opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/80 to-black" />
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-7xl flex-col items-center px-6 pt-32 pb-24 lg:flex-row lg:justify-between">
        <motion.div
          initial={{ opacity: 0, x: -60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-yellow-500/40 bg-yellow-500/10 px-5 py-2">
            <ShieldCheck className="h-4 w-4 text-yellow-400" />

            <span className="text-sm font-semibold uppercase tracking-widest text-yellow-300">
              Faith • Honor • Strength
            </span>
          </div>

          <h1 className="text-5xl font-black leading-tight text-white md:text-7xl">
            Premium
            <span className="gold-text"> Mobile </span>
            Auto Detailing
          </h1>

          <p className="mt-8 max-w-2xl text-lg leading-8 text-gray-300">
            Legacy Auto Detailing LLC delivers luxury-level detailing,
            ceramic coatings, paint correction, interior restoration,
            and maintenance memberships designed to protect your
            investment and keep your vehicle looking better than new.
          </p>
                <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a
              href="#contact"
              className="gold-button inline-flex items-center justify-center gap-2 rounded-full px-8 py-4 text-lg"
            >
              Book Your Detail
              <ArrowRight className="h-5 w-5" />
            </a>

            <a
              href="#pricing"
              className="outline-button inline-flex items-center justify-center rounded-full px-8 py-4 text-lg font-semibold"
            >
              View Pricing
            </a>
          </div>

          <div className="mt-12 grid gap-5 sm:grid-cols-3">
            <div className="glass rounded-2xl p-6 text-center">
              <Star className="mx-auto mb-3 h-8 w-8 text-yellow-400" />

              <h3 className="text-3xl font-black text-white">
                5★
              </h3>

              <p className="mt-2 text-gray-300">
                Premium Customer Experience
              </p>
            </div>

            <div className="glass rounded-2xl p-6 text-center">
              <Sparkles className="mx-auto mb-3 h-8 w-8 text-yellow-400" />

              <h3 className="text-3xl font-black text-white">
                100%
              </h3>

              <p className="mt-2 text-gray-300">
                Satisfaction Guaranteed
              </p>
            </div>

            <div className="glass rounded-2xl p-6 text-center">
              <ShieldCheck className="mx-auto mb-3 h-8 w-8 text-yellow-400" />

              <h3 className="text-3xl font-black text-white">
                20%
              </h3>

              <p className="mt-2 text-gray-300">
                Military & First Responder Discount
              </p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.9 }}
          className="mt-20 w-full max-w-xl lg:mt-0"
        >
          <div className="glass rounded-3xl border border-yellow-500/20 p-8 shadow-2xl">
            <h2 className="gold-text text-3xl font-black">
              Legacy Membership
            </h2>

            <p className="mt-4 text-gray-300">
              Keep your vehicle looking showroom ready year-round with our
              exclusive monthly detailing memberships.
            </p>
                 <div className="mt-8 space-y-5">
              <div className="flex items-center justify-between rounded-xl border border-yellow-500/20 bg-white/5 p-4">
                <div>
                  <h3 className="text-lg font-bold text-white">
                    Bronze Membership
                  </h3>

                  <p className="text-sm text-gray-400">
                    Monthly Exterior Maintenance
                  </p>
                </div>

                <span className="text-2xl font-black text-yellow-400">
                  $49/mo
                </span>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-yellow-500/30 bg-yellow-500/10 p-4">
                <div>
                  <h3 className="text-lg font-bold text-white">
                    Silver Membership
                  </h3>

                  <p className="text-sm text-gray-300">
                    Exterior + Interior Maintenance
                  </p>
                </div>

                <span className="text-2xl font-black text-yellow-400">
                  $99/mo
                </span>
              </div>

              <div className="flex items-center justify-between rounded-xl border border-yellow-500/40 bg-yellow-500/20 p-4">
                <div>
                  <h3 className="text-lg font-bold text-white">
                    Gold Membership
                  </h3>

                  <p className="text-sm text-gray-300">
                    Complete Premium Maintenance Plan
                  </p>
                </div>

                <span className="text-2xl font-black text-yellow-400">
                  $199/mo
                </span>
              </div>
            </div>

            <div className="mt-8 rounded-2xl border border-yellow-500/30 bg-yellow-500/10 p-5">
              <p className="text-center text-base font-semibold text-yellow-300">
                🇺🇸 Military, Veterans & First Responders receive
                <span className="font-black text-white">
                  {" "}20% OFF{" "}
                </span>
                all detailing services with valid ID.
              </p>
            </div>

            <a
              href="#contact"
              className="gold-button mt-8 flex w-full items-center justify-center rounded-full px-8 py-4 text-lg"
            >
              Become a Legacy Member
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
